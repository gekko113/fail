public class Main {

    public static void main(String[] args) {
        ValidateTransaction firstValidation = new MinLimit();
        ValidateTransaction secondValidation = new MaxLimit();

        firstValidation.setNext(secondValidation);
        firstValidation.check(new MoneyTransaction(20000));

    }
}
class MaxLimit extends  ValidateTransaction{

    public void check(MoneyTransaction moneyTransaction) {
        if (moneyTransaction.getAmount() > 10000) {
            System.out.println("Превышен макс. размер транкзации");
        }
    }
}
class MinLimit extends ValidateTransaction {

    public void check(MoneyTransaction moneyTransaction) {
        if (moneyTransaction.getAmount() > 1000) {
            System.out.println("Необходимо ввсти пин-код");
        }

        checkNext(moneyTransaction);
    }
}
class MoneyTransaction {

    public MoneyTransaction(double amount) {
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }
    private double amount;
}
abstract class ValidateTransaction {

    private ValidateTransaction next;

    public void setNext(ValidateTransaction next) {
        this.next = next;
    }

    protected void checkNext(MoneyTransaction moneyTransaction) {
        if (next != null) {
            next.check(moneyTransaction);
        }
    }
    public abstract void check(MoneyTransaction moneyTransaction);
}